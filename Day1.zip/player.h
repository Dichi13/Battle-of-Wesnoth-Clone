#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "unit.h"
#include "stdio.h"
#include "pcolor.h"

#define Nil NULL
#define InitGold 200
#define IncomePerVillage 10
#define UpkeepPerUnit 3

typedef struct P{
	int Gold;
	Unit *UnitP;
	POINT *Village;
	int Income;
	int Upkeep;
} Player;

typedef Unit infotype;
typedef struct LUnit *addressUnit
typedef struct LUnit {
	infotype info;
	addressUnit next;
} UnitList;

/* Selektor-selektro List Unit */
#define Info(U) (U)->info
#define Next(U)	(U)->next
/* Selektor-selektor Player*/
#define Gold(P) (P).Gold
#define Income(P) (P).Income
#define Upkeep(P) (P).Upkeep
#define ListUnit(P) (P).UnitP
#define ListVillage(P) (P).Village

/* Primitif-primitif Player */

void CreatePlayer(Player *P);
/* Membuat player*/
void PrintUnitPlayer(Player P);
/* Mencetak unit yang dimiliki player */





#endif