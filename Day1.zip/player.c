#include "player.h"

/* Primitif-primitif Player */

void CreatePlayer(Player *P) {
/* Membuat player*/
	Gold(*P) = InitGold;
	Income(*P) = 0;
	Upkeep(*P) = 0;
	ListUnit(*P) = Nil;
	ListVillage(*P) = Nil;
}

void PrintUnitPlayer(Player P) {
/* Mencetak unit yang dimiliki player */
	
}